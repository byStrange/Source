# Cleave.js Documentation 

[Documentation](https://github.com/nosir/cleave.js/blob/master/doc/doc.md) > JavaScript API

- [Constructor](https://github.com/nosir/cleave.js/blob/master/doc/constructor.md)
- [Options](https://github.com/nosir/cleave.js/blob/master/doc/options.md)
- [Public methods](https://github.com/nosir/cleave.js/blob/master/doc/public-methods.md)
